var CONFIG = {
    "androidUrl": "https://itunes.apple.com/us/app/solitaire-grand-harvest/id1223338261?mt=8&ign-mpt=uo%3D4",
    "appleUrl": "https://play.google.com/store/apps/details?id=net.supertreat.solitaire&hl=ru",
    "amazonUrl": "",
    "gameEvents": {
        "time-after-interaction": {
            "time": 15000,
            "cta": false,
            "activation": "interaction"
        },
        "interaction": {
            "interactions": 30,
            "cta": false
        },
        "time": {
            "time": 20000,
            "cta": false
        },
        "time-after-outro": {
            "time": 2500,
            "cta": true,
            "activation": "outro"
        }
    },
    "outro-if-no-interaction": {
        "isAble": true,
        "time": 10000
    },
    "I18": {
        "locale": "en",
        "strings": {
            "DOWNLOAD": {
                "en": "Download"
            },
            "RETRY": {
                "en": "Retry"
            },
            "YOU_WON": {
                "en": "CONGRATULATIONS! YOU WON!"
            },
            "YOU_LOST": {
                "en": "SORRY! YOU LOST! RETRY?"
            }
        }
    },

    textColor: {
        DOWNLOAD: [0xFFFFFF, 0xFFE75F],
        RETRY: [0xFFFFFF, 0xFFE75F],
        YOU_WON: [0xFFE75F, 0xEECA02],
        YOU_LOST: [0xFFE75F, 0xEECA02],
        STROKE: 0x37000
    },
    "application": {
        "showFPS": false,
        "skipOutro": false,
        tutorial: {
            isAble: true,
            startIn: 500,
            pointAtCard: 20
        }
    }
};

CONFIG.backStepsAmount = Infinity;
CONFIG.hintTimout = 3000;

/*Suits of cards*/
CONFIG.suits = {
    DIAMONDS: "diamonds", CLUBS: "clubs", HEARTS: "hearts", SPADES: "spades"
};

/*Types of cards*/
CONFIG.types = {
    TWO: 2, THREE: 3, FOUR: 4, FIVE: 5, SIX: 6, SEVEN: 7, EIGHT: 8, NINE: 9, TEN: 10, JACK: "J", QUEEN: "Q", KING: "K", ACE: "A"
};

/*The deck of cards which are at the bottom of the screen*/
CONFIG.baseDeck = [
    { id: 0, isDeckCard: true, isOpen: true, type: CONFIG.types.TWO, suit: CONFIG.suits.CLUBS, loc: { x: 100, y: 0 }, links: { above: [], below: [] } },
    { id: 1, isDeckCard: true, isOpen: false, type: CONFIG.types.JACK, suit: CONFIG.suits.DIAMONDS, loc: { x: -100, y: 0 }, links: { above: [], below: [2] } },
    { id: 2, isDeckCard: true, isOpen: false, type: CONFIG.types.FOUR, suit: CONFIG.suits.SPADES, loc: { x: -130, y: 0 }, links: { above: [1], below: [3] } },
    { id: 3, isDeckCard: true, isOpen: false, type: CONFIG.types.KING, suit: CONFIG.suits.DIAMONDS, loc: { x: -160, y: 0 }, links: { above: [2], below: [4] } },
    { id: 4, isDeckCard: true, isOpen: false, type: CONFIG.types.FOUR, suit: CONFIG.suits.SPADES, loc: { x: -190, y: 0 }, links: { above: [3], below: [5] } },
    { id: 5, isDeckCard: true, isOpen: false, type: CONFIG.types.SIX, suit: CONFIG.suits.HEARTS, loc: { x: -210, y: 0 }, links: { above: [4], below: [6] } },
    { id: 6, isDeckCard: true, isOpen: false, type: CONFIG.types.NINE, suit: CONFIG.suits.SPADES, loc: { x: -240, y: 0 }, links: { above: [5], below: [7] } },
    { id: 7, isDeckCard: true, isOpen: false, type: CONFIG.types.FOUR, suit: CONFIG.suits.DIAMONDS, loc: { x: -270, y: 0 }, links: { above: [6], below: [] } }
];
/*The deck of cards which are at the center of the screen*/
CONFIG.playingCards = [
    { id: 1, isOpen: false, type: CONFIG.types.EIGHT, suit: CONFIG.suits.DIAMONDS, loc: { x: -150, y: 0 }, angle: 0, links: { above: [2, 5], below: [] } },
    { id: 2, isOpen: false, type: CONFIG.types.KING, suit: CONFIG.suits.DIAMONDS, loc: { x: -180, y: -120 }, angle: -10, links: { above: [3], below: [1] } },
    { id: 3, isOpen: false, type: CONFIG.types.QUEEN, suit: CONFIG.suits.SPADES, loc: { x: -230, y: -160 }, angle: -12, links: { above: [4], below: [2] } },
    { id: 4, isOpen: true, type: CONFIG.types.ACE, suit: CONFIG.suits.HEARTS, loc: { x: -280, y: -200 }, angle: -15, links: { above: [], below: [3] } },
    { id: 5, isOpen: false, type: CONFIG.types.THREE, suit: CONFIG.suits.SPADES, loc: { x: -180, y: 120 }, angle: 10, links: { above: [6], below: [1] } },
    { id: 6, isOpen: false, type: CONFIG.types.FIVE, suit: CONFIG.suits.HEARTS, loc: { x: -230, y: 160 }, angle: 12, links: { above: [7], below: [5] } },
    { id: 7, isOpen: true, type: CONFIG.types.SEVEN, suit: CONFIG.suits.SPADES, loc: { x: -280, y: 200 }, angle: 15, links: { above: [], below: [6] } },

    { id: 8, isOpen: false, type: CONFIG.types.FIVE, suit: CONFIG.suits.SPADES, loc: { x: 0, y: -120 }, angle: 0, links: { above: [9], below: [] } },
    { id: 9, isOpen: false, type: CONFIG.types.NINE, suit: CONFIG.suits.CLUBS, loc: { x: 0, y: -170 }, angle: 0, links: { above: [10], below: [8] } },
    { id: 10, isOpen: true, type: CONFIG.types.KING, suit: CONFIG.suits.SPADES, loc: { x: 0, y: -220 }, angle: 0, links: { above: [], below: [9] } },

    { id: 11, isOpen: false, type: CONFIG.types.TWO, suit: CONFIG.suits.SPADES, loc: { x: 0, y: 120 }, angle: 0, links: { above: [12], below: [] } },
    { id: 12, isOpen: false, type: CONFIG.types.FOUR, suit: CONFIG.suits.DIAMONDS, loc: { x: 0, y: 170 }, angle: 0, links: { above: [13], below: [11] } },
    { id: 13, isOpen: true, type: CONFIG.types.EIGHT, suit: CONFIG.suits.CLUBS, loc: { x: 0, y: 220 }, angle: 0, links: { above: [], below: [12] } },

    { id: 14, isOpen: false, type: CONFIG.types.FOUR, suit: CONFIG.suits.CLUBS, loc: { x: 150, y: 0 }, angle: 0, links: { above: [15, 18], below: [] } },
    { id: 15, isOpen: false, type: CONFIG.types.THREE, suit: CONFIG.suits.HEARTS, loc: { x: 180, y: -120 }, angle: 10, links: { above: [16], below: [14] } },
    { id: 16, isOpen: false, type: CONFIG.types.SIX, suit: CONFIG.suits.SPADES, loc: { x: 230, y: -160 }, angle: 12, links: { above: [17], below: [15] } },
    { id: 17, isOpen: true, type: CONFIG.types.TEN, suit: CONFIG.suits.DIAMONDS, loc: { x: 280, y: -200 }, angle: 15, links: { above: [], below: [16] } },
    { id: 18, isOpen: false, type: CONFIG.types.ACE, suit: CONFIG.suits.SPADES, loc: { x: 180, y: 120 }, angle: -10, links: { above: [19], below: [14] } },
    { id: 19, isOpen: false, type: CONFIG.types.TWO, suit: CONFIG.suits.HEARTS, loc: { x: 230, y: 160 }, angle: -12, links: { above: [20], below: [18] } },
    { id: 20, isOpen: true, type: CONFIG.types.THREE, suit: CONFIG.suits.HEARTS, loc: { x: 280, y: 200 }, angle: -15, links: { above: [], below: [19] } }
];
