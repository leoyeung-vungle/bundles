var isMuted = true;
var muteOpacity;
var muteFile = config.sound === 'muted' ? 'mute' : 'unmute'


var baseURL = ''
var preInsert = baseURL.includes("{baseURL}") ? 'resources/' : baseURL

// $('#volume-icon').attr('src','' + muteFile + '.svg')
$('#volume-icon').attr('src',preInsert + muteFile + '.svg')


muteOpacity = setTimeout(function() {
    $('#volume-icon').addClass('mute-hidden');
}, 5000)

$('#video-elem').click(function() {
    console.log(isMuted)
    $('#volume-icon').removeClass('mute-hidden');
    if (isMuted) {
        $('video').prop('muted', false);
        $('#volume-icon').attr('src', baseURL + 'unmute.svg')
    } else {
        $('video').prop('muted', true);
        $('#volume-icon').attr('src', baseURL + 'mute.svg')
    }
    isMuted = !isMuted;
    clearTimeout(muteOpacity)
    muteOpacity = setTimeout(function() {
        $('#volume-icon').addClass('mute-hidden');
    }, 2500)
});

