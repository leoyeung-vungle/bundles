var config = {
	contentType: 'videos',
    sound: 'muted',
    videos: {
        portrait: 'a7c64f55-363c-4246-b8bc-1e27cd3cfa7b.mp4',
        landscape: 'bc1c26c0-7e8e-4ae7-8a6b-810e4ecce9f1.mp4'
    },
    images: {
        portrait: '',
        landscape: ''
    }
}

// var config = {
//     contentType: 'videos',
//     sound: 'muted',
//     videos: {
//         portrait: 'videos/portrait.mp4',
//         landscape: 'videos/landscape.mp4'
//     },
//     images: {
//         portrait: '',
//         landscape: ''
//     }
// }