var colourThemes = {
    black: {
        cta: '#009aff'
    },
    purple: {
        cta: '#622762'
    },
    blue: {
        cta: '#009aff'
    },
    green: {
        cta: '#05c237'
    },
    red: {
        cta: '#e50606'
    },
    orange: {
        cta: '#ffb800'
    }
}

console.log('settings.js page');
var baseURL = ''
var videoURL = ''
var defaultTheme = 'green' // Do not edit this.
var defaultIcon = 'download' // Do not edit this.


var PiecSettings = PiecSettings || {};

PiecSettings.videoOrientation = "";
PiecSettings.orientationLock = ""; //Choose between "portrait", "landscape" and "none"

PiecSettings.version = "-";
PiecSettings.preInsertResources = baseURL.includes("{baseURL}") ? 'resources/' : baseURL;
PiecSettings.preInsertImages = baseURL.includes("{baseURL}") ? 'images/' : baseURL;
PiecSettings.preInsertVideos = baseURL.includes("{baseURL}") ? 'videos/' : baseURL;
PiecSettings.videoURL = videoURL.includes("{video}") ? PiecSettings.preInsertVideos + PiecSettings.videoOrientation + '.mp4' : videoURL;
//========================== General Settings. Timer, ASOI, fonts =============================
PiecSettings.timer = false;
PiecSettings.timerDuration = 6000;
PiecSettings.asoi = false;


PiecSettings.fontColor = "#fff";
PiecSettings.fontFamily = "sans-serif"; //Make sure that this font is on the css and that there is a div that uses it. (preload-font div)
PiecSettings.genericFontFamily = "sans-serif";


PiecSettings.initialScript = "opener";
PiecSettings.script = {
    'opener': {
        video: PiecSettings.videoURL,
        from: 0,
        loop: true,
        hud: [],
    },
};

//======================================== CTA PHRASE LOCALISATION ========================================

var language = typeof languageOverride !== 'undefined' ? languageOverride : getDeviceLang();
var phrase = '';
var ctaText = '';

if (!(phrase.includes("{cta-phrases}")) && phrase.length > 0) {
    if (typeof localisation[phrase] !== 'undefined' && typeof localisation[phrase][language] !== 'undefined')
        ctaText = localisation[phrase][language]
    else
        ctaText = localisation[phrase]['en']
}


//======================================== HUD Elements ========================================
PiecSettings.hudElements = {};

var ctaType = 'no-cta';

    PiecSettings.script.opener.hud = [
        { tag: 'cta', at: 0.01, show: true, triggerOnce: true },
    ];
    PiecSettings.hudElements = {
        'cta': {
            src: '',
            htmlTag: 'cta-rectangle',
            anchor: { x: 0.5, y: 0.5 },
            type: 'cta',
        },
    };

    if (ctaType.includes("image-and-localised-phrase") || ctaType.includes("image-and-custom-text")) {
        PiecSettings.hudElements['download-txt'] = {
            text: ctaText,
            htmlTag: 'cta-rectangle-text',
            anchor: { x: 0.5, y: 0.5 },
            style: {
                fontWeight: "bold",
                fontFamily: PiecSettings.fontFamily,
                fontCase: 'uppercase',
                color: ['#fff'], // if there is no gradient, leave only one color in the array
                stroke: '#fff',
                strokeThickness: 0,
                shadow: {
                    x: 2,
                    y: 2,
                    color: 'rgba(0,0,0,.1)',
                    blur: 0,
                    shadowStroke: true,
                    shadowFill: true,
                },
            },
        }
        PiecSettings.script.opener.hud.push({ tag: 'download-txt', at: 0.01, show: true, triggerOnce: true });
}

//============Variables and Flags used within the Video PIEC script to apply conditions and consequences=================
PiecSettings.variables = {};

//=================================== Collectible Component ====================================
PiecSettings.collectibles = {};

//================================= Mini Games (e.g. projectile) ===============================
PiecSettings.minigames = {};

//===================================== Png Animations =========================================
PiecSettings.pngAnimations = {}

PiecSettings.defaultLang = "en";
PiecSettings.translations = localisation