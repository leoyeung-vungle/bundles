var video = document.getElementById('video-elem');
var image = document.getElementById('video-elem');

var oldOrientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';


initContent(oldOrientation);

function initContent(orientation) {
    if (config.contentType === 'videos')
        initVideo(orientation);
    else
        initImage(orientation);
}


window.addEventListener('resize', function() {
    var newOrientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
    if (oldOrientation !== newOrientation) {
        initContent(newOrientation);
        oldOrientation = newOrientation;
    }
});

window.addEventListener('ad-event-pause', function() {
    pause();
});

window.addEventListener('ad-event-resume', function() {
    resume();
});

function initVideo(orientation) {
    video.src = config.videos[orientation]
}

function initImage(orientation) {
    image.src = config.images[orientation]
}

function pause() {
    video.pause();
}

function resume() {
    video.play();
}