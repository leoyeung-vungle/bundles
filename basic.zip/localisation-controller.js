var language = typeof languageOverride !== 'undefined' ? languageOverride : getDeviceLang();

function getDeviceLang() {
    var lang;
    if (navigator.userLanguage) {
        lang = navigator.userLanguage;
        lang = lang.split("-")[0].toLowerCase();
    } else if (navigator.language) {
        lang = navigator.language;
        lang = lang.split("-")[0].toLowerCase();
    } else {
        lang = "en";
    }
    return lang;
}

localiseElements();

function localiseElements() {
    var divs = document.getElementsByClassName("localised-text");

    for (var i = 0; i < divs.length; i++) {
        if (typeof localisation !== 'undefined' && Object.keys(localisation).length > 0) {
            var phrase = divs[i].getAttribute('data-localisation');
            if (phrase !== '') {
                if (typeof localisation[phrase] !== 'undefined' && typeof localisation[phrase][language] !== 'undefined')
                    divs[i].innerHTML = localisation[phrase][language]
                else
                    divs[i].innerHTML = localisation[phrase]['en']
            }
        }
    }
}