var cta = document.getElementById('cta');
var ctaText = document.getElementById('cta-text');

resizeText(ctaText)

function resizeText(elem) {
    elem.style.fontSize = null;
    var unitType = ((window.innerHeight > window.innerWidth) ? 'vw' : 'vh');
    var newsize = adjustFontSize(elem) + unitType;
    console.log(newsize);
    elem.style.fontSize = newsize;
}

function adjustFontSize(elem) {
    var newfontSize;
    var minimumSize = .5;
    addClass(elem,'stopWrapping');
    var parent = elem.parentElement;
    var currentWidth = elem.offsetWidth;
    var currentFontSize = parseFloat(getStyle(elem, 'fontSize'));

    if (window.innerHeight > window.innerWidth) {
        currentFontSize = currentFontSize / document.body.offsetWidth * 100;
    } else {
        currentFontSize = currentFontSize / document.body.offsetHeight * 100;
    }

    var rect = elem.getBoundingClientRect();
    var parentRect = parent.getBoundingClientRect();
    var divOffset = rect.left - parentRect.left;
    if (currentWidth > parent.offsetWidth * .95 || currentWidth + divOffset > parent.offsetWidth * .95) {
        var percentage;
        if (currentWidth > parent.offsetWidth * .95) {
            percentage = parent.offsetWidth / currentWidth;
        } else {
            percentage = parent.offsetWidth / (currentWidth + divOffset);
        }

        if (currentFontSize * percentage > currentFontSize * minimumSize) {
            newfontSize = currentFontSize * percentage * .90;
        } else {
            addClass(elem,'truncate');
        }
    }
    removeClass(elem,'stopWrapping');
    return newfontSize;
}


window.addEventListener('resize', function() {
    resetTransitions();
    resizeText(ctaText)
}, true);

function resetTransitions() {
    var divs = document.getElementsByClassName("transition");
    for (var i = 0; i < divs.length; i++) {
        addClass(divs[i], 'blockTransition');
        removeClassWithDelay(divs[i], 'blockTransition')
    }
}

function removeClassWithDelay(elem, cssClass, delay){
        setTimeout(function() {
            removeClass(elem, cssClass);
        }, delay);
}